// Needed to use Boost as static libraries with GCC
#define BOOST_THREAD_USE_LIB

// Use boost::future instead of boost::unique_future
#define BOOST_THREAD_PROVIDES_FUTURE

#include <algorithm>                    // std::reverse
#include <iostream>                     // std::cout/endl
#include <string>                       // std::string
#include <vector>                       // std::vector
#include <boost/thread/future.hpp>      // boost:future/packaged_task
#include <boost/thread/thread.hpp>      // boost:thread

using namespace std;

string flip(string s)
{
    reverse(s.begin(), s.end());
    return s;
}

int main()
{
    vector<boost::future<string> > v;

    {
        boost::packaged_task<string> pt([] { return flip( " ,olleH"); });
        v.push_back(pt.get_future());
        boost::thread task(boost::move(pt));
    }
    {
        boost::packaged_task<string> pt([] { return flip("\n!letnI"); });
        v.push_back(pt.get_future());
        boost::thread task(boost::move(pt));
    }

    for (auto i = v.begin(); i != v.end(); ++i) {
        cout << i->get();
    }
}
