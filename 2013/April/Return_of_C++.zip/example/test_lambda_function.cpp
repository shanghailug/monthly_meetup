#include <iostream>
#include <functional>
#include <typeinfo>

using namespace std;

int main()
{
    auto l1 = []() {};
    auto l2 = []() {};
    cout << typeid(l1).name() << endl;
    cout << typeid(l2).name() << endl;
    function<void()> f = [&]() { cout << "Hello World\n"; };
    cout << typeid(f).name() << endl;
    f();
}
