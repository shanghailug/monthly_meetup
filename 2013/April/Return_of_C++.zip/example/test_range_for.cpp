#include <iostream>

using namespace std;

int main()
{
    for (int x : { 1, 1, 2, 3, 5 }) {
        cout << x << endl;
    }
}
