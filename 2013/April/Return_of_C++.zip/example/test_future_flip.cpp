#include <algorithm>                    // std::reverse
#include <future>                       // std::future/async
#include <iostream>                     // std::cout/endl
#include <string>                       // std::string
#include <vector>                       // std::vector

using namespace std;

string flip(string s)
{
    reverse(s.begin(), s.end());
    return s;
}

int main()
{
    vector<future<string>> v;

    v.push_back(async([] { return flip( " ,olleH"); }));
    v.push_back(async([] { return flip("\n!letnI"); }));

    for (auto& e : v) {
        cout << e.get();
    }
}
