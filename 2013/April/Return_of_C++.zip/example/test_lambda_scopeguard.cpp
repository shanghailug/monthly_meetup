#include <stdio.h>
#include <functional>

using namespace std;

class ScopeGuard {
public:
    ScopeGuard(function<void()> func) : func_(func), dismissed_(false) {}
    ~ScopeGuard() { if (!dismissed_) func_(); }
    void Dismiss() { dismissed_ = true; }
private:
    function<void()> func_;
    bool dismissed_;
};

#define CONCATENATE2(s1, s2) s1##s2
#define CONCATENATE(s1, s2) CONCATENATE2(s1, s2)
#define ON_SCOPE_EXIT(func) \
    ScopeGuard CONCATENATE(on_scope_exit_, __LINE__)((func))

FILE* myopen(const char* file, const char* mode)
{
    FILE* fp = fopen(file, mode);
    if (fp == NULL) {
        perror("Fail to open file");
    } else {
        printf("File %p is opened\n", fp);
    }
    return fp;
}

int myclose(FILE* fp)
{
    int retcode = fclose(fp);
    printf("File %p is closed\n", fp);
    return retcode;
}

int main()
{
    FILE* fp = myopen("test.cpp", "r");
    if (fp == NULL)
        return 1;
    ON_SCOPE_EXIT([&]() { myclose(fp); });
    // Consider the following style if Dismiss() needs to be used
    //ScopeGuard guard([&]() { myclose(fp); });
    //guard.Dismiss();
}
