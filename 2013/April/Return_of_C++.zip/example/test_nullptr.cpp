#include <stddef.h>                     // NULL
#include <iostream>                     // std::cout/endl

using namespace std;

void test(void*)
{
    cout << "test(void*)" << endl;
}

void test(int)
{
    cout << "test(int)" << endl;
}

int main()
{
    test(NULL);      // This can be ambiguous--or call test(int)!
    test(nullptr);   // This calls correctly test(void*).
}
