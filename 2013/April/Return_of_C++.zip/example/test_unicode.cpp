char n[] = "GCC and MSVC encode differently: \u2018.";
wchar_t w[] = L"Is it 16-bit or 32-bit: \u2018?";

#if __cplusplus >= 201103L || \
	(defined(__GNUC__) && __GNUC__ * 100 + __GNUC_MINOR__ >= 405)

char a[] = u8"UTF-8 string: \u2018.";
char16_t b[] = u"UTF-16 string: \u2018.";
char32_t c[] = U"UTF-32 string: \u2018.";

#endif

int main()
{
}
