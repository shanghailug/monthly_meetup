#include <algorithm>                    // std::copy/for_each
#include <iostream>                     // std::cout/endl
#include <iterator>                     // std::ostream_iterator/begin/end

using namespace std;

int main()
{
    int array[5] = { 1, 2, 3, 4, 5 };
    copy(begin(array), end(array), ostream_iterator<int>(cout, " "));
    cout << endl;
    //for (int& x : array) {
    //    x *= 2;
    //}
    for_each(begin(array) + 1,
             end(array) - 1,
             [](int& x) { x *= 2; });
    for_each(begin(array),
             end(array),
             [](int x) { cout << x << " "; });
    cout << endl;
}
