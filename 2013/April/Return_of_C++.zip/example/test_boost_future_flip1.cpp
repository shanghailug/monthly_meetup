// Needed to use Boost as static libraries with GCC
#define BOOST_THREAD_USE_LIB

// Use boost::future instead of boost::unique_future
#define BOOST_THREAD_PROVIDES_FUTURE

#include <algorithm>                    // std::reverse
#include <functional>                   // std::function
#include <iostream>                     // std::cout/endl
#include <string>                       // std::string
#include <vector>                       // std::vector
#include <boost/thread.hpp>             // boost::future/async

using namespace std;

string flip(string s)
{
    reverse(s.begin(), s.end());
    return s;
}

static string tmp1() { return flip( " ,olleH"); }
static string tmp2() { return flip("\n!letnI"); }

int main()
{
    vector<boost::future<string> > v;

    v.push_back(boost::async(tmp1));
    v.push_back(boost::async(tmp2));

    for (auto i = v.begin(); i != v.end(); ++i) {
        cout << i->get();
    }
}
