#include <string>                       // std::string

using std::string;

int main()
{
    string s0("my mother told me that");
    string s1("cute");
    string s2("fluffy");
    string s3("kittens");
    string s4("are an essential part of a healthy diet");

    string dest = s0 + " " + s1 + " " + s2 + " " + s3 + " " + s4;
}
