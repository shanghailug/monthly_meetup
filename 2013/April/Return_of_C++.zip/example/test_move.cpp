#include <iostream>                     // std::cout/endl
#include <string>                       // std::string
#include <utility>                      // std::move/swap

using namespace std;

#if __cplusplus >= 201103L || \
    (defined(__GNUC__) && __GNUC__ * 100 + __GNUC_MINOR__ >= 406)
#define NOEXCEPT noexcept
#else
#define NOEXCEPT throw()
#endif

#define DISPLAY_AND_RUN(str) cout << #str ";"; str;

class Object {
public:
    Object();
    Object(const string&);
    Object(string&&) NOEXCEPT;

    Object(const Object&);
    Object(Object&&) NOEXCEPT;

    Object& operator=(const Object&);
    Object& operator=(Object&&) NOEXCEPT;

    void swap(Object&) NOEXCEPT;

    const string& str() const NOEXCEPT;

private:
    string str_;
};

Object::Object()
{
    cerr << " --> Object()";
}

Object::Object(const string& str) : str_(str)
{
    cerr << " --> Object(const string&)";
}

Object::Object(string&& str) NOEXCEPT : str_(std::move(str))
{
    cerr << " --> Object(string&&)";
}

Object::Object(const Object& obj) : str_(obj.str_)
{
    cerr << " --> Object(const Object&)";
}

Object::Object(Object&& obj) NOEXCEPT : str_(std::move(obj.str_))
{
    cerr << " --> Object(Object&&)";
}

Object& Object::operator=(const Object& obj)
{
    cerr << " --> Object::operator=(const Object&)";
    Object tmp(obj);
    swap(tmp);
    return *this;
}

Object& Object::operator=(Object&& obj) NOEXCEPT
{
    cerr << " --> Object::operator=(Object&&)";
    Object tmp(std::move(obj));
    swap(tmp);
    return *this;
}

void Object::swap(Object& obj) NOEXCEPT
{
    cerr << " --> Object::swap(Object&)";
    std::swap(str_, obj.str_);
}

const string& Object::str() const NOEXCEPT
{
    return str_;
}

int main()
{
    DISPLAY_AND_RUN(Object obj1("Hello"));
    cout << "\nobj1 contains \"" << obj1.str() << "\"\n";
    DISPLAY_AND_RUN(Object obj2);
    cout << "\nobj2 contains \"" << obj2.str() << "\"\n";
    DISPLAY_AND_RUN(obj2 = obj1);
    cout << "\nobj1 contains \"" << obj1.str() << "\"\n"
         <<   "obj2 contains \"" << obj2.str() << "\"\n";
    DISPLAY_AND_RUN(obj2 = Object("World"));
    cout << "\nobj2 contains \"" << obj2.str() << "\"\n";
    DISPLAY_AND_RUN(obj2 = std::move(obj1));
    cout << "\nobj1 contains \"" << obj1.str() << "\"\n"
         <<   "obj2 contains \"" << obj2.str() << "\"\n";
    DISPLAY_AND_RUN(Object obj3(std::move(obj2)));
    cout << "\nobj2 contains \"" << obj2.str() << "\"\n"
         <<   "obj3 contains \"" << obj3.str() << "\"\n";
}
